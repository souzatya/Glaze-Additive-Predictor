
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.8.1'
version = '1.8.1'
full_version = '1.8.1'
git_revision = '4cf21e7'
commit_count = '2331'
release = True

if not release:
    version = full_version
